Opis plikow oprogramowania alarmu przecowpowodziowego

1. main.py
	Program glowny ktory kontroluje czy alarm dziala poprawnie, jeżeli z jakiegoś powodu przestaną działać wątki
	odpowiedzialne za obsługę czujników i kontrole urządzenia użytkownik i administrator zostaną powiadomieni o 
	tym fakcie. Dodatkowo kolor  diody zotanie zmieniony na czerony. Z tego pliku jest wywoływany proces detektor.py.

2. detektor.py
	Kolejny proces głowny obsługuje wątki odpowiedzialne za odczyty z czujeników wody (YL-83) i temperatury (DHT11), 
	Z niego jest też uruchamiany wątek do obsługi panelu przedniego.

3. internet.py
	Biblioteka programu zawierająca głównie funkcje związane z internetem oraz z kontrolą błędów programu.

3. dht11.py
	Biblioteka do obsługi czujnika temperatury DHT11.

4. front_panel.py
	Biblioteka obsługująca panel przedni  tj.: wyświetlanie informacji na wyświetlaczu, obsługa klawiszy funkcyjnych

5. wyswietlacz.py
	Bibliteka obsługująca tylko wyswietlacz LCD 2x16 znaków wykożystywana we front_ppanelu

6. pliki.py
	Biblioteka zawierająca ścierzki do plików programu, oraz dane dosępowe do baz danych oraz konta email

7. test_baza.py 
	Program napisany do sprawdzania poprawności danych wprowadzanych do baz danych

#****
8. detektor.conf

	!!!JEST TO JEDYNY PLIK KTÓRY MOŻNA EDYTOWAĆ W SPOSÓB OPISANY W PLIKU !!!
	
	Plik konfiguracyjny programu w którym uruchamia się czujniki wody i temperatury oraz można ustawić opisy tych czujników
	Po jakiejkolwiek zmianie najepiej uruchomić urządzenie od nowa !!!!

9,10,11. DHT_1, DHT_2, DHT_3
	Są to pliki programu do których program wpisuje odczyty z czujników temperatury i wilgotności są wykożystywane przez 
	biblioteke obsługującą panel przedni (front_panel)

12. emails
	plik do którego po uruchomieniu programu są pobierane adresy na które mają zostać wysłane wiadomości, w razie problemów z alarmem i bazą danych z turaszówki na te adresy zostanie wysłane stosowne powiadomienie.

13. local_baza.db
	Jest to lokalna baza danych programu SQLite.

14. sleep
	Plik zawierający flagę uśpienia programu na czas 15 minut
