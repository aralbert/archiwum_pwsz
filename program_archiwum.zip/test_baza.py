import sqlite3
import psycopg2
import front_panel

#Program kontrolny do polaczenia z bazami danych
#Pobiera i wyswietla wszystkie 16 rekordow z bazy 
#lokalne i umiejscowionej na serverze w turaszowce


print "**************BAZA LOKALNA**************************************"
time = front_panel.get_Date() + " " +front_panel.get_Time()
conn = sqlite3.connect('local_baza.db')
cursor = conn.execute("SELECT ID, ID_CZUJNIKA, TEMPERATURA, WILGOTNOSC, WODA, ERROR, DATA  from GLOWNA")
for row in cursor:
   print "ID = ", row[0]
   print "ID_CZUJNIKA = ", row[1]
   print "TEMPERATURA = ", row[2]
   print "WILGOTNOSC = ", row[3]
   print "WODA = ", row[4]
   print "ERROR = ", row[5]
   print "DATA = ", row[6], "\n"


try:
	email = []
	conn = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
	print "Palaczono z baza :D"
	print time
	print "**********************BAZA GLOBALNA********************************************"
	cur = conn.cursor()
	cur.execute("SELECT *  from adresy_email")
	rows = cur.fetchall()
	#print str(rows)
	for row in rows:
   		print "ID = ", row[0]
   		print "EMAIL = ", row[1]
   		email.append(row[1])

	cur.execute("SELECT *  from wprowadz_odczyty")
	rows = cur.fetchall()
	#print str(rows)/
        #cur.execute("UPDATE wprowadz_odczyty SET error = (%s) WHERE id_czujnika = 16",( 34567,))
	conn.commit()
	for row in rows:
		print "ID_CZUJNIKA = ", row[0]
		print "TEMPERATURA = ", row[1]
		print "WILGOTNOSC = ", row[2]
		print "WODA = ", row[3]
		print "ERROR  = ", row[4]
		print "DATA = ", row[5], "\n"
	
	#update =  "UPDATE wprowadz_odczyty SET error = '"+str(456)+"' data = '"+str(time)+"' WHERE id_czujnika = 16;"
	#cur.execute("UPDATE wprowadz_odczyty SET error = (%s), data = (%s) WHERE id_czujnika = 16", (34567,time,));
	#cur.execute(str(update))


	print "Operation done successfully";
	print str(email)
	conn.commit()
	conn.close()

	email_file = open('emails', 'a')
	for i in range(len(email)):                                           
		email_file.write(str(email[i])+"\n")
	email_file.close()


except :
	print "nie polaczylo :/"
