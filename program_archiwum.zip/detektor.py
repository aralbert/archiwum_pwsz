# -*- coding: utf-8 -*-

from __future__ import division
from time import sleep
from datetime import datetime

import wyswietlacz
import dht11
import front_panel 
import internet
import pliki

import RPi.GPIO as GPIO
import math
import os
import sys
import ConfigParser
import time
import thread
import Queue


#porty podpietych uzadzen
#czujnik wody
T_YL = [5, 6, 13, 19, 26, 25, 8, 7, 12, 16, 20, 21]  # numery portow GPIO
T_iYL = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]      # identyfikatory 1-12 dla portow GPIO
T_oYL = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]      # odczyty z portow
T_pYL = []
#czujnik temperatury
T_DHT = [18, 15, 14]
T_iDHT = [1, 2, 3]
T_tDHT = [1, 2, 3]
T_hDHT = [1, 2, 3]

T_fDHT = [1, 2, 3]
temperatura = 0
wilgotnosc = 0
tekst_wysw = ''

#przyciski
OK = 10
UP = 9
DOWN = 11

czas = 0
sek = 0

suma = 0
mail_w = 0

#interwal zapisow
interwal = 0


#Lista adresow e-mail do wyslania powiadomienia
#T_EMAIL = []


#
#Funkcja inicjujaca alarm, odczyt ktore czujniki sa podlaczone
#oraz zczytanie maili
#
def init():
# zmienne pomocnicze
	opisy = []
	global interwal
	global T_fDHT
	global T_pYL
	internet.remove_db()
	rm = 0 # ilosc wyrazow do usuniecia
#cztanie ustawien z pliku config.conf
	config = ConfigParser.RawConfigParser()
	try:
		file_config = open(pliki.detektor_conf)
		config.readfp(file_config)
	except:
		internet.write_log(10)
	interwal = config.getint('USTAWIENIA','delay')
#Ustawienie YL-83
	for i in range(0, 12):
		stan = config.get('YL-83',str(i))
		T_pYL.append(config.get('YL_opis',str(i)))

		if stan == 'no':
			rm += 1
			T_YL[i] = 0   
			T_iYL[i] = 0  
			T_oYL[i] = 0  

	for i in range(0, rm):
		T_YL.remove(0)
		T_iYL.remove(0)
		T_oYL.remove(0)


#Ustawienie DHT11
	rm = 0
	for i in range(0, 3):
		stan = config.get('DHT11',str(i))
		if stan == 'no':
			rm += 1
			T_DHT[i] = 0
			T_iDHT[i] = 0
			T_tDHT[i] = 0
			T_hDHT[i] = 0
			T_fDHT[i] = 0


	for i in range(0, rm):
		T_DHT.remove(0)
		T_iDHT.remove(0)
		T_tDHT.remove(0)
		T_hDHT.remove(0)

# odczyt maili z pliku
	#ile = config.getint('E-MAIL','ilosc')
	#for i in range(0, ile):
	#	adres = config.get('E-MAIL',str(i))
	#	T_EMAIL.append(adres)

	opisy.append(config.get('DHT_opis','1'))
	opisy.append(config.get('DHT_opis','2'))
	opisy.append(config.get('DHT_opis','3'))

#konfiguracja portow GPIO dla YL-83
	GPIO.setmode(GPIO.BCM)
	for pin in T_YL:
		GPIO.setup(pin, GPIO.IN)

#GPIO led ustawienia
	#GPIO.setup(RED, GPIO.OUT)
	#GPIO.setup(GREEN, GPIO.OUT)
	file_config.close()
	front_panel.init_front(T_fDHT, opisy)
	internet.init_net(T_pYL,opisy)
	internet.create_db()
#koniec funkcji init
#******************************************************************************************

#odczyt z czujnikow wody
def YL_83(pin):
	if GPIO.input(pin):
		return  0
	else:
		return  1 
#koniec funkcji dla yl

#*********************************************************************************************
#Obsluga odczytow z czujnikow DHT11 temperatura + wilgotnosc 
#Te odczyty sa wysylane na wyswietlacz
def DHT_read():
#Odczyt z dht11
		global mail_w
		blad_odczytu1 = 0
		blad_odczytu2 = 0
		blad_odczytu3 = 0
		while(True):
			#*********************************************************************
			plik = open(pliki.sleep)
			try:
				tekst = plik.read()
			finally:
				plik.close()
			if tekst == "NO":
			#*********************************************************************
				#internet.clear_file('dht_s')
				for i in range(len(T_DHT)):
					wilgotnosc, temperatura = dht11.dht(T_DHT[i])
					if wilgotnosc != -10 and temperatura != -10:
						T_hDHT[i] = wilgotnosc
						T_tDHT[i] = temperatura
						if int(temperatura) > 60 and internet.info_list.count(i+29) == 0:
							internet.info_list.append(i+29)
							internet.write_log(i+29)
						if int(wilgotnosc) > 60 and internet.info_list.count(i+29) == 0:
							internet.info_list.append(i+32)
							internet.write_log(i+32)
						if i == 0 :
							blad_odczytu1 = 0
						else:
							blad_odczytu1 +=1
							if blad_odczytu1 > 10:
								internet.write_log(12)

						if i == 1 :
							blad_odczytu2 = 0
						else:
							blad_odczytu2 +=1
							if blad_odczytu2 > 10:
								internet.write_log(13)

						if i == 2 :
							blad_odczytu3 = 0
						else:
							blad_odczytu3 +=1
							if blad_odczytu3 > 10:
								internet.write_log(14)

				#try:
				#	f_save = open('dht_s','w')
				#except:
				#	internet.write_log(6)

				for i in range(len(T_iDHT)):
					print '\n czujnik nr.: ' + str(T_iDHT[i])  
					print ' Temperatura : ' + str(T_tDHT[i])
					print ' wilgotnosc : ' + str(T_hDHT[i])
					if i == 0:
						try:
							plik = open(pliki.dht_1,'w')
						except:
							internet.write_log(3)


					elif i == 1:
						try:
							plik = open(pliki.dht_2,'w')
						except:
							internet.write_log(4)

					elif i == 2:
						try:
							plik = open(pliki.dht_3,'w')
						except:
							internet.write_log(5)

					plik.write("H: "+str(T_hDHT[i]) + "%  T:"+str(T_tDHT[i])+ " *C")
					#f_save.writelines(str(T_iDHT[i])+"\t"+str(T_tDHT[i])+"\t"+str(T_hDHT[i]) + "\n")
					plik.close()
				#f_save.close()
				
				if int(len(internet.info_list)) > 0 and mail_w == 0:
					internet.send_email()
					mail_w = 1
					#internet.info_list = []

				internet.write_error_db()
				time.sleep(interwal)

			
			else :
				sleep_15_m()
				plik = open(pliki.sleep,'w')
				plik.write("NO")
				plik.close()


#*********************************************************************************************
#funkcja obslugujaca uspienie programu na 15 minut
def sleep_15_m():

	sek = 0
	minuts = 0
	T_sYL = T_oYL
	T_stDHT = T_tDHT
	T_shDHT = T_hDHT

	print'USPIENIE CZUJNIKOW NA 15 MINUT !!'
	while(minuts < 15):
		time.sleep(1)
		sek +=1
		if sek == interwal:
			if internet.thread_db.empty() == True:
				thread.start_new_thread(internet.write_db,(T_iYL, T_oYL, T_iDHT, T_tDHT, T_hDHT))
		if sek == 60:
			sek = 0
			minuts += 1
		

			
#*********************************************************************************************
#Glowna funkcja programu odczyty z czujnikow wody yl-83
def detektor_main():
	#zmienna do wypisawania listy w linii
	wypisz = ""
	global mail_w
	global sek
	global suma
	
	print '\n\n Interwal = ' +str(interwal)
	print '\n\n     YL-83'
	for i in range(len(T_iYL)):
		print ' | %2d  =  %2d | ' %(T_iYL[i], T_YL[i])
	#	j += 1

	#j = 0
	print '\n\n     DHT11'
	for i in range(len(T_iDHT)):
		print ' | %2d  =  %2d | ' %(T_iDHT[i], T_DHT[i])
		#j += 1

	#j = 0
	#print '\n\n       Adresy e-mail'
	#for i in range(len(T_EMAIL)):
	#	print  '\n ', i,' = ',T_EMAIL[i], 
		#j += 1


#odczyty z czujnikow !!!!!

	#j = 0	
	#print '\n\n       Odczyty z czujnikow YL-83'
	try:
		while True:
			suma = 0
			#*********************************************************************
			try:
				plik = open(pliki.sleep)
			except:
				internet.write_log(7)
			try:
				tekst = plik.read()
			finally:
				plik.close()
			if tekst == "NO":
			#*********************************************************************
				#internet.clear_file('yl_s')
				#print datetime.now().strftime('\n %Y-%m-%d')
				#print time.strftime(" %H:%M:%S")
				for i in range(len(T_iYL)):
					T_oYL[i] = YL_83(T_YL[i])
					suma = T_oYL[i] + suma

					if T_oYL[i] == 1 and internet.info_list.count(i+17) == 0:
						#print str(internet.info_list)
						internet.info_list.append(i+17)
						internet.write_log(i+17)

				if suma == 0:
					internet.info_list = []
					mail_w = 0

				for o in T_iYL:
					wypisz += ' | ' + str(o)
				#print wypisz
				wypisz = ''
				for o in T_oYL:
					wypisz += ' | ' + str(o)

				#print wypisz
				wypisz = ''
				j=0
				#try:
				#	f_yl = open('yl_s','w')
				#except:
				#	internet.write_log(8)
				#for i in range(len(T_iYL)):
				#	f_yl.writelines(str(T_iYL[i])+"\t"+str(T_oYL[i])+"\n")
				#f_yl.close()

				#if internet.ping("baza") == "inactive":
				#	front_panel.led("red")

				#print "\n" + internet.ping("global")

				time.sleep(1)
				sek += 10
				#print sek
				if sek >= int(interwal):
					sek = 0
					internet.write_db(T_iYL, T_oYL, T_iDHT, T_tDHT, T_hDHT)
					#if internet.thread_db.empty() == True:
						#thread.start_new_thread(internet.write_db,(T_iYL, T_oYL, T_iDHT, T_tDHT, T_hDHT))


				#print "thread_db = "+str(internet.thread_db.empty())


				if len(internet.info_list) > 0:
					internet.write_db(T_iYL, T_oYL, T_iDHT, T_tDHT, T_hDHT)
					
				#print 'dl info : ' + str(len(internet.info_list))
				

				#kontrola temperatury raspi
				if internet.temp_rpi() > 70 and internet.info_list.count(16) != 0:
					internet.info_list.append(16)
					internet.write_log(16)
				
			else :
				sleep_15_m()
				try:
					plik = open(pliki.sleep,'w')
					plik.write("NO")
					plik.close()
				except:
					internet.write_log(7)
	finally:
		GPIO.cleanup()		 

def main():
	try:
		init()
		wyswietlacz.lcd_main('Trwa ','uruchamianie ... ')
  		thread.start_new_thread(front_panel.front_main, ())
		thread.start_new_thread(DHT_read,( ))
  		thread.start_new_thread(detektor_main())
  		
  				
	except:
   		#print "Error: unable to start thread"
   		internet.write_log(11)
   		wyswietlacz.lcd_main('','')
   		sys.exit(0)
   	


if __name__ == '__main__':
	main()






