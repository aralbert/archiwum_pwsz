# -*- coding: utf-8 -*-
#
#Tu jest uruchamiany glowny program do czujnikow wody (biblioteka detektor.py)
#oraz jest kontrolowane czy program dziala poprawnie 
#W razie problemow dioda swieci na czerwono + wyslanie maila i zapisanie bazy
#
from __future__ import division
from time import sleep
from datetime import datetime
from multiprocessing import Process

import sys
import os

import detektor
import front_panel 
import internet
import pliki

import RPi.GPIO as GPIO
import ConfigParser
import time

RED = 23
GREEN = 24
#T_EMAIL = []

def led(kolor):
	GPIO.setmode(GPIO.BCM)
	GPIO.setup(RED, GPIO.OUT)
	GPIO.setup(GREEN, GPIO.OUT)
	if kolor == 'green':
		GPIO.output(RED, GPIO.HIGH)	
		GPIO.output(GREEN, GPIO.LOW)
	elif kolor == 'red':
		GPIO.output(GREEN, GPIO.HIGH)	
		GPIO.output(RED, GPIO.LOW)

if __name__ == '__main__':
    try:
    	config = ConfigParser.RawConfigParser()
    	file_config = open(pliki.detektor_conf)
    	config.readfp(file_config)
    	#ile = config.getint('E-MAIL','ilosc')
        #for i in range(0, ile):
        #    adres = config.get('E-MAIL',str(i))
        #    T_EMAIL.append(adres)
        file_config.close()

        internet.get_email()
        #internet.send_email()

    	p = Process(target=detektor.main, args=())
    	p.start()
    	
    	while True:
        	time.sleep(0.1)
        	led("green")

    	p.join()
    except:
    	internet.write_log(36)
    	internet.write_error_db()
    	internet.info_list.append(36)
    	#print "dodano informacje"
    	#print str(T_EMAIL)
    	#internet.init_net(T_EMAIL,[])
    	internet.send_email()
    	time.sleep(0.1)
    	led("red")

