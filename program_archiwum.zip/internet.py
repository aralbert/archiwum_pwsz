# -*- coding: utf-8 -*
#Funkcje do kontroli systemu + obsluga funkcji internetowych
import subprocess
import os
import time
from datetime import datetime
import sqlite3
import smtplib
import linecache
import psycopg2
import Queue


import front_panel
import pliki


cmd = "/opt/vc/bin/vcgencmd measure_temp"

update_time = "sudo ntpdate 0.pl.pool.ntp.org"

e_mail = []

info_list = []

error_list = []

T_pYL = []

T_pDHT = []

#thread_db = Queue.Queue()

T_errors_db = []

#*********************************************************************************************
def get_email():
	global e_mail
	try:
		
		conn = psycopg2.connect(dbname=pliki.db_name, user=pliki.db_user, password=pliki.db_pass, host=pliki.db_host, port=pliki.db_port)
		#conn = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
		#print "Palaczono z baza"
		e_mail = []
		cur = conn.cursor()
		cur.execute("SELECT *  from adresy_email")
		rows = cur.fetchall()
		#print str(rows)
		for row in rows:
			#print "ID = ", row[0]
			#print "EMAIL = ", row[1]
			e_mail.append(row[1])

		e_mail.append(pliki.mail_addr)
		conn.close()
		clear_file('emails')

		email_file = open(pliki.emails, 'a')
		for i in range(len(e_mail)):                                           
			email_file.write(str(e_mail[i])+"\n")
		email_file.close()

		#print str(e_mail)
	except :
		write_log(2)
		e_mail = []
		#print "Brak polaczenia z baza *****"

		count = len(open(pliki.emails, 'rU').readlines())
		for i in range(count):
			e_mail.append(linecache.getline(pliki.emails, i))



#*********************************************************************************************

#Utworzenie bazy danych (lokalna)
def create_db():

	try:
		conn = sqlite3.connect(pliki.db_local)
		conn.execute('''CREATE TABLE GLOWNA
		(ID INTEGER PRIMARY KEY AUTOINCREMENT,
		 ID_CZUJNIKA INT NOT NULL,
		 TEMPERATURA INT,
		 WILGOTNOSC INT,
		 WODA CHAR(1),
		 ERROR TEXT,
		 DATA TEXT NOT NULL); ''')


		time = front_panel.get_Date() + " " +front_panel.get_Time()

		for i in range(16):
			conn.execute('''INSERT INTO GLOWNA (ID_CZUJNIKA,DATA) \
			 VALUES(?,?)''',(i+1,time));



		conn.commit()
		conn.close()
		#print "utworzono baze lokalna"
	except:
		write_log(35)

		


	try:
		conn2 = psycopg2.connect(dbname=pliki.db_name, user=pliki.db_user, password=pliki.db_pass, host=pliki.db_host, port=pliki.db_port)
		#conn2 = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
		cur = conn2.cursor()
		for i in range(1,17):
			cur.execute("UPDATE wprowadz_odczyty SET temperatura = NULL, wilgotnosc = NULL, woda = NULL, error = NULL, data = (%s) WHERE id_czujnika = (%s)",(time,i,))
			conn2.commit()
		conn2.commit()
		conn2.close

		#print "Zrobiono baze globalna"
	except:
		write_log(2)

	

#*********************************************************************************************
#Zapis do lokalnej bazy danych (będzie dodana globalna)
def write_db(i_yl, o_yl, i_dht, t_dht, h_dht):
	#print str(T_errors_db)
	#print "zapis bazy"
	front_panel.run_cmd(update_time)
	time = front_panel.get_Date() + " " +front_panel.get_Time()
	#if ping("baza") == "inactive":
	try:
		conn = sqlite3.connect(pliki.db_local)
	#	thread_db.put(1)
		for i in range(len(i_yl)):
			conn.execute('''UPDATE GLOWNA SET WODA = ?, DATA = ? WHERE ID = ?''',
			 (int(o_yl[i]),time,int(i_yl[i])));
			conn.commit()
			

		for i in range(len(i_dht)):
			conn.execute('''UPDATE GLOWNA SET TEMPERATURA = ?, WILGOTNOSC = ?, DATA = ? WHERE ID = ?''',
			 (int(t_dht[i]),int(h_dht[i]),time,int(i_dht[i]+12)));
			conn.commit()

			

		conn.execute('''UPDATE GLOWNA SET TEMPERATURA = ?, DATA = ? WHERE ID = 16''',
			 (int(temp_rpi()),time));

		conn.commit()
		conn.close()
	except:
		write_log(35)
		#----------------------------------------------------------------------------------------------------------------------------

	try:
		conn2 = psycopg2.connect(dbname=pliki.db_name, user=pliki.db_user, password=pliki.db_pass, host=pliki.db_host, port=pliki.db_port)
		#conn2 = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
		cur = conn2.cursor()
		#print "jest polaczenie"
		for i in range(len(i_yl)):
			cur.execute("UPDATE wprowadz_odczyty SET woda = (%s), data = (%s) WHERE id_czujnika = (%s)",(o_yl[i],time,i_yl[i],))
			conn2.commit()

		for i in range(len(i_dht)):
			cur.execute("UPDATE wprowadz_odczyty SET temperatura = (%s), wilgotnosc = (%s), data = (%s) WHERE id_czujnika = (%s)",(t_dht[i],h_dht[i],time,i_dht[i]+12,))
			conn2.commit()

		temp = int(temp_rpi())
		#print str(temp)
		cur.execute("UPDATE wprowadz_odczyty SET temperatura = (%s), data = (%s) WHERE id_czujnika = 16",(temp,time,))
		#print "T_RPI OK"

		
		conn2.commit()
		conn2.close
		#write_error_db()
		#print "zapisano baze globalna "
		#thread_db.get()
	except:
		write_log(2)
		#print "globalna nie zostala zapisana"
	

#*********************************************************************************************
#Zapisanie bledow do bazy (narazie lokalna)

def write_error_db():
	global error_list
	global T_errors_db
	error_text = ""
	if len(error_list) > 0:
		time = front_panel.get_Date() + " " +front_panel.get_Time()
	#if ping("baza") == "inactive":
		try:
			for i in error_list:
				error_text += str(i)
				error_text += ";"
				T_errors_db.append(i)
			#print error_text
			conn = sqlite3.connect(pliki.db_local)
			conn2 = psycopg2.connect(dbname=pliki.db_name, user=pliki.db_user, password=pliki.db_pass, host=pliki.db_host, port=pliki.db_port)
			#conn2 = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
			cur = conn2.cursor()
			conn.execute('''UPDATE GLOWNA SET ERROR = ?, DATA = ? WHERE ID = 16''',
			 (error_text,time));

			cur.execute("UPDATE wprowadz_odczyty SET error = (%s), data = (%s) WHERE id_czujnika = 16",(error_text,time,))
			
			#print "Error OK"

			conn.commit()
			conn.close()
			conn2.commit()
			conn2.close()


			#print "zapisano blendy "
			#conn2.close()
		except:
			write_log(35)





#*********************************************************************************************
#Dodanie informacji do listy

#def put_info(info):
#	global info_list
#	info_list.append(info)

#*********************************************************************************************
#Wyszukiwanie duplikatow w liscie z informacjami
#def find_error_duplicate(info):
#	error_db = []
#	conn2 = psycopg2.connect(dbname='pwsz', user='rpi1', password='pwsz207', host='194.169.226.55', port='5555')
#	cur = conn2.cursor()
#	cur.execute("SELECT error FROM wprowadz_odczyty WHERE id_czujnika = 16")
#	rows = cur.fetchall()
#	conn2.commit()
#	return info_list.count(info)

#*********************************************************************************************
#usuniecie bazy (chyba nie potrzebne)
def remove_db():
	sciezkaDoPliku=pliki.db_local
	if os.path.isfile(sciezkaDoPliku) :
		os.unlink(sciezkaDoPliku)

#*********************************************************************************************
#wczytanie adresow email + opisow do czujnikow

def init_net( opisy, dht):
	get_email()

	global T_pYL
	T_pYL = opisy

	global T_pDHT
	T_pDHT = dht


#*********************************************************************************************



def ping(host):
	ip = ""
	if host == "baza":
		ip == "192.168.1.3"
	elif host == "global":
		ip == "8.8.8.8"
	with open(os.devnull, "wb") as limbo:
		result=subprocess.Popen(["ping", "-c", "1", "-n", "-W", "2", ip],stdout=limbo, stderr=limbo).wait()
		if result:
			return "active"
		else:
			return "inactive"

#*********************************************************************************************
#Wysylanie maila

def send_email():
	try:
		global info_list
		get_email()
		#print str(info_list)
		tresc = str(front_panel.get_Date()) + "\n" + str(front_panel.get_Time()) +"\n\n"
		#fromaddr = 'archiwum.raspi@interia.pl' 

		for i in info_list:
			#print str(info_list)
			if i >= 17 and i <= 28:
				tresc += info_code(i) +"  "+T_pYL[i-17]

			elif i>=29 and i<=34:
				tresc += info_code(i) +"  "+T_pDHT[i-29]

			else:
				tresc += info_code(i) + "\n"

		#print tresc	

		msg ="""From: Archiwum PWSZ <monitorowanie_archiwum@pwsz.krosno.pl>
To: Do praconikow <monitorowanie_archiwum@pwsz.krosno.pl>
Subject: Alarm z czujników

""" + tresc


		server = smtplib.SMTP_SSL(pliki.mail_server)
		server.ehlo()
		#server.starttls()
		server.login(pliki.mail_addr,pliki.mail_pass)
		server.sendmail(pliki.mail_addr, e_mail, msg)
		server.quit()
		#print "Wyslano maila"
		info_list = []
	except:
		write_log(1)

#*********************************************************************************************
#Czyszczenie pliku

def clear_file(file):
	plik = open(file, 'w')
	plik.write("")
	plik.close()

#*********************************************************************************************
#Zapis LOGA
def write_log(info):
	data =  front_panel.get_Date()
	godzina = front_panel.get_Time()
	logfile = open(pliki.log, 'a')                                           
	logfile.write(str(data) + "  "+ str(godzina)+ "  "+ str(info_code(info))+"\n")
	logfile.close()
	global error_list
#	global T_errors_db
	error_list.append(info)

#*********************************************************************************************
#Odczyt temperatury Komputera
def temp_rpi():
	temp = front_panel.run_cmd(cmd)
	return float(temp[5:-3])

#*********************************************************************************************
#Kody informacji

def info_code(id):
	if id == 1:
		return "Error 001 : Blad poczty email."
	elif id == 2:
		return "Error 002 : Brak połączenia z bazą danych."
	elif id == 3:
		return "Error 003 : Blad pliku dht_1."
	elif id == 4:
		return "Error 004 : Blad pliku dht_2."
	elif id == 5:
		return "Error 005 : Blad pliku dht_3."
	elif id == 6:
		return "Error 006 : Blad pliku dht_s."
	elif id == 7:
		return "Error 007 : Blad pliku sleep."
	elif id == 8:
		return "Error 008 : Blad pliku yl_s."
	elif id == 9:
		return "Error 009 : Blad pliku porty.conf."
	elif id == 10:
		return "Error 010 : Blad pliku detektor.conf."
	elif id == 11:
		return "Error 011 : Blad uruchomienia watku."
	elif id == 12:
		return "Error 012 : Blad czujnika temperatury DHT11 nr. 1."
	elif id == 13:
		return "Error 013 : Blad czujnika temperatury DHT11 nr. 2."
	elif id == 14:
		return "Error 014 : Blad czujnika temperatury DHT11 nr. 3."
	elif id == 15:
		return "Error 015 : Blad wyswietlacza."
	elif id == 16:
		return "Error 016 : Zbyt wysoka temperatura urzadzenia."
	elif id == 17:
		return "Wykryto wode na czujniku nr.: 1."
	elif id == 18:
		return "Wykryto wode na czujniku nr.: 2."
	elif id == 19:
		return "Wykryto wode na czujniku nr.: 3."
	elif id == 20:
		return "Wykryto wode na czujniku nr.: 4."
	elif id == 21:
		return "Wykryto wode na czujniku nr.: 5."
	elif id == 22:
		return "Wykryto wode na czujniku nr.: 6."
	elif id == 23:
		return "Wykryto wode na czujniku nr.: 7."
	elif id == 24:
		return "Wykryto wode na czujniku nr.: 8."
	elif id == 25:
		return "Wykryto wode na czujniku nr.: 9."
	elif id == 26:
		return "Wykryto wode na czujniku nr.: 10."
	elif id == 27:
		return "Wykryto wode na czujniku nr.: 11."
	elif id == 28:
		return "Wykryto wode na czujniku nr.: 12."
	elif id == 29:
		return "Zbyt wysoka temperatura na czujniku nr.: 1."
	elif id == 30:
		return "Zbyt wysoka temperatura na czujniku nr.: 2."
	elif id == 31:
		return "Zbyt wysoka temperatura na czujniku nr.: 3."
	elif id == 32:
		return "Zbyt wysoka wilgotnosc na czujniku nr.: 1."
	elif id == 33:
		return "Zbyt wysoka wilgotnosc na czujniku nr.: 2."
	elif id == 34:
		return "Zbyt wysoka wilgotnosc na czujniku nr.: 3."
	elif id == 35:
		return "Blad lokalnej bazy danych."
	elif id == 36:
		return "Alarm przestal dzialac. Nieznany blad."
