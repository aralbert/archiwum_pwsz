# -*- coding: utf-8 -*-

from __future__ import division
from datetime import datetime
#from time import sleep
import time

import wyswietlacz
import dht11
import internet
import pliki

import RPi.GPIO as GPIO
import math
import os
import ConfigParser
from subprocess import *


cmd = "ip addr show eth0 | grep inet | awk '{print $2}' | cut -d/ -f1"

#czujniki DHT11
T_DHT = []

#Opisy czujnikow DHT:
T_oDHT = []

#przyciski
OK = 10
UP = 9
DOWN = 11

czas = 0


#Wywolanie komendy systemowej
def run_cmd(cmd):
	p = Popen(cmd, shell = True, stdout = PIPE)
	output = p.communicate()[0]
	return output
#*********************************************************************************************
#Pobranie IP
def get_IP():
        ipaddr = run_cmd(cmd)
        ip = '%s' % ( ipaddr ) 
        return ip
#*********************************************************************************************
#Pobranie i sformatowanie daty
def get_Date():
	data = datetime.now().strftime('%Y-%m-%d')
	return data
#*********************************************************************************************
#Pobranie i sformatowanie godziny
def get_Time():
	czas = time.strftime("%H:%M:%S")
	return czas

#*********************************************************************************************
#Obsluga uspienia na 15 minut
def sleep_15():

	sek = 0
	minuts = 0
	while(minuts < 15):
		time.sleep(1)
		sek +=1
		if sek == 60:
			sek = 0
			minuts += 1
		message = '     ' + str(minuts) + ' : ' + str(sek)
		wyswietlacz.lcd_main("ALARM OFF 15 min",message)





#******************************************************************************
#Ustawienia dla panelu przedniego
def init_front(dht_id, dht_o):
	GPIO.setmode(GPIO.BCM)
	GPIO.setup(OK, GPIO.IN)    
	GPIO.setup(UP, GPIO.IN)
	GPIO.setup(DOWN, GPIO.IN)
	global T_DHT
	global T_oDHT
	T_DHT = dht_id
	T_oDHT = dht_o

	try:
		plik = open(pliki.sleep,'w')
		plik.write("NO")
		plik.close()
	except:
		internet.write_log(7)

#*************************************************************************************
#Funkcja glowna dla panelu przedniego
def front_main():
	try :
		key = 0
		print_id = 2
		aktualizacja = 100
		t_ok = 0
		lock = 0
		while(True):
			time.sleep(0.1)
			#if internet.ping("global") == "inactive":
			#	led("red")
			#else:
			#	led('green')

			aktualizacja += 1
			if t_ok == 1:
				lock += 1
				if lock == 50:
					lock = 0
					t_ok = 0

			if GPIO.input(OK) == True:
				t_ok += 1
				time.sleep(2)
				if(t_ok == 2):
					print 'OK'
					try:
						plik = open(pliki.sleep,'w')
						plik.write("YES")
						plik.close()
					except:
						internet.write_log(7)
					sleep_15()
					t_ok = 0
					
			if GPIO.input(UP) == True:
				wyswietlacz.lcd_main('Chwileczke','pracuje...')
				print 'UP'
				time.sleep(2)
				wyswietlacz.lcd_main('','')
				aktualizacja = 110
				if(print_id < 1):
					print_id = 5
				elif(print_id > 5):
					print_id = 1
				print_id += 1
				print 'ID = ' + str(print_id)

		
			if GPIO.input(DOWN) == True:
				wyswietlacz.lcd_main('Chwileczke','pracuje...')
				print 'DOWN'
				time.sleep(2)
				wyswietlacz.lcd_main('','')
				aktualizacja = 110
				if(print_id < 1):
					print_id = 5
				elif(print_id > 5):
					print_id = 1
				print_id -= 1
				print 'ID = ' + str(print_id)
		
					
#***********************************************************************************************
			if(print_id <= 1):
				if(aktualizacja >= 100):
					dlugosc = get_IP().index("\n")
					tekst = get_IP()[0:dlugosc]
					wyswietlacz.lcd_main('Adres IP :',tekst)
					aktualizacja = 0

			elif(print_id == 2):
				if T_DHT[0] == 1:
						if(aktualizacja >= 100):
							try:
								plik = open(pliki.dht_1)
							except:
								internet.write_log(3)

							try:
								tekst = plik.read()
							finally:
								plik.close()
							
							wyswietlacz.lcd_main(str(T_oDHT[0]),tekst)
							aktualizacja = 0
				else:
					if(aktualizacja >= 100):
						wyswietlacz.lcd_main(str(T_oDHT[0]),'T: N/C   H: N/C')
						aktualizacja = 0

			elif(print_id == 3):
				if T_DHT[1] == 2:
						if(aktualizacja >= 100):
							try:
								plik = open(pliki.dht_2)
							except:
								internet.write_log(4)
							try:
								tekst = plik.read()
							finally:
								plik.close()
							
							wyswietlacz.lcd_main(str(T_oDHT[1]),tekst)
							aktualizacja = 0
				else:
					if(aktualizacja >= 100):
						wyswietlacz.lcd_main(str(T_oDHT[1]),'T: N/C   H: N/C')
						aktualizacja = 0

			elif(print_id == 4):
				if T_DHT[2] == 3:
						if(aktualizacja >= 100):
							try:
								plik = open(pliki.dht_3)
							except:
								internet.write_log(4)
							try:
								tekst = plik.read()
							finally:
								plik.close()
							
							wyswietlacz.lcd_main(str(T_oDHT[2]),tekst)
							aktualizacja = 0
				else:
					if(aktualizacja >= 100):
						wyswietlacz.lcd_main(str(T_oDHT[2]),'T: N/C   H: N/C')
						aktualizacja = 0

			elif(print_id == 5):
				if(aktualizacja >= 10):
					wyswietlacz.lcd_main(str(get_Date()),str(get_Time()))
					aktualizacja = 0

			elif(print_id >= 6):
				if aktualizacja >= 100:
					wyswietlacz.lcd_main('Procesor : ',"Temp : "+str(internet.temp_rpi())+"*C")
					aktualizacja = 0

	finally :
		GPIO.cleanup()
