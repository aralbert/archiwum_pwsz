
#Plik konfiguracyjny alarmu
detektor_conf = '/usr/local/sbin/detektor/detektor.conf'

#Uspienie alarmu (NIE EDYTOWAC !!!!)
sleep = '/usr/local/sbin/detektor/sleep'

#odczyty z czujnikow DHT do wyswietlenia na ekranie
dht_1 = '/usr/local/sbin/detektor/dht_1'
dht_2 = '/usr/local/sbin/detektor/dht_2'
dht_3 = '/usr/local/sbin/detektor/dht_3'

#Plik z mailami (lokalna kopia adresow z bazy)
emails = '/usr/local/sbin/detektor/emails'

#Plik kolalnej bazy danych SQLite'
db_local = '/usr/local/sbin/detektor/local_baza.db'

#Plik loga programowego
log = '/usr/local/sbin/detektor/detektor.log'

#palaczenie do globalnej bazy w Turaszowce na wirtualce
#conn = psycopg2.connect(dbname=pliki.db_name, user=pliki.db_user, password=pliki.db_pass, host=pliki.db_host, port=pliki.db_port)
db_name = 'pwsz'
db_user = 'rpi1'
db_pass = 'pwsz207'
db_host = '194.169.226.55'
db_port = '5555'

#Dostepy do serwera email

mail_addr = 'monitorowanie_archiwum@pwsz.krosno.pl'
mail_pass = 'Dkeuywhs7@'
mail_server = 'mail.pwsz.krosno.pl:465'